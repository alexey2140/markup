

PLEASE READ THE LICENSE TO MAKE SURE YOU ABIDE BY IT.

You may NOT:

- Resale the enclosed files, no matter what.
- Re-distribute the enclosed files without permission from Jekin Gala.
- Post any of the designs to your Dribbble, Behance or any site for that matter without tweaking it first and not without crediting Jekin Gala.

You may:

- Go nuts with these and have fun.
